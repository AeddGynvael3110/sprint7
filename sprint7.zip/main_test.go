package main

import (
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestCafeNegative(t *testing.T) {
	handler := http.HandlerFunc(mainHandle)

	tests := []struct {
		request string
		status  int
		message string
	}{
		{"/cafe", http.StatusBadRequest, "unknown city"},
		{"/cafe?city=omsk", http.StatusBadRequest, "unknown city"},
		{"/cafe?city=tula&count=na", http.StatusBadRequest, "incorrect count"},
	}
	for _, tt := range tests {
		response := httptest.NewRecorder()
		req := httptest.NewRequest("GET", tt.request, nil)
		handler.ServeHTTP(response, req)

		assert.Equal(t, tt.status, response.Code)
		assert.Equal(t, tt.message, strings.TrimSpace(response.Body.String()))
	}
}

func TestCafeWhenOk(t *testing.T) {
	handler := http.HandlerFunc(mainHandle)

	tests := []string{
		"/cafe?count=2&city=moscow",
		"/cafe?city=tula",
		"/cafe?city=moscow&search=ложка",
	}
	for _, tt := range tests {
		response := httptest.NewRecorder()
		req := httptest.NewRequest("GET", tt, nil)

		handler.ServeHTTP(response, req)

		assert.Equal(t, http.StatusOK, response.Code)
	}
}

func TestCafeCount(t *testing.T) {
	countTests := []struct {
		count int
		want  int
	}{
		{0, 0},
		{1, 1},
		{2, 2},
		{100, len(cafeList["moscow"])}, // Москва имеет 5 кафе
	}

	for _, ct := range countTests {
		t.Run("count="+strconv.Itoa(ct.count), func(t *testing.T) {
			response := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodGet, "/cafe?city=moscow&count="+strconv.Itoa(ct.count), nil)

			mainHandle(response, req)

			require.Equal(t, http.StatusOK, response.Code)

			cafes := strings.Split(strings.TrimSpace(response.Body.String()), ",")
			if ct.count == 0 {
				require.Len(t, cafes, 1)
				require.Empty(t, cafes[0]) // ожидание пустой строки
			} else {
				require.Len(t, cafes, ct.want)
			}
		})
	}
}

func TestCafeSearch(t *testing.T) {
	handler := http.HandlerFunc(mainHandle)

	// Определяем тестовые случаи
	requests := []struct {
		search    string // передаваемое значение search
		wantCount int    // ожидаемое количество кафе в ответе
	}{
		{"фасоль", 0}, // ожидаемое количество: 0
		{"кофе", 2},   // ожидаемое количество: 2
		{"вилка", 1},  // ожидаемое количество: 1
	}

	for _, req := range requests {
		t.Run("search="+req.search, func(t *testing.T) {
			response := httptest.NewRecorder()
			// Создаем новый запрос с заданными параметрами (город и строка поиска)
			request := httptest.NewRequest(http.MethodGet, "/cafe?city=moscow&search="+req.search, nil)

			// Обрабатываем запрос
			handler.ServeHTTP(response, request)

			// Проверяем статус ответа
			require.Equal(t, http.StatusOK, response.Code)

			// Получаем ответ в виде строки и разделяем его на срез кафе
			cafes := strings.Split(strings.TrimSpace(response.Body.String()), ",")

			// Проверяем количество найденных кафе
			require.Len(t, cafes, req.wantCount)

			// Если ожидается хотя бы одно кафе, проверяем, что в названии содержится строка поиска
			for _, cafe := range cafes {
				assert.True(t, strings.Contains(strings.ToLower(cafe), strings.ToLower(req.search)), "Cafe name should contain search term")
			}
		})
	}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
